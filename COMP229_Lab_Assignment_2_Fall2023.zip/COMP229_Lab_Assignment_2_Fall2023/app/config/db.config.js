module.exports = {url:"mongodb+srv://Admin1:123@cluster0.g88soon.mongodb.net/Marketplace?retryWrites=true&w=majority"};

